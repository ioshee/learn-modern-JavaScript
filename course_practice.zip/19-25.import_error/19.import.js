// error
/* 
import { capitalizeString } from "./string_fun";

import * as capitalizeString from "string_fun";
 */
const cap = capitalizeString("hello");

console.log(cap);
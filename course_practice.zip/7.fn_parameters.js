/* concise function */
const myConcat = (arr1, arr2) => arr1.concat(arr2); 
/* full function */
/* const myConcat = function(arr1, arr2) {
    return arr1.concat(arr2);
};
 */
console.log(myConcat([1,2], [3, 4, 5]));

/* concise function */
const magic = () => new Date();
/* full function */
/* const magic = function() {
    return new Date();
}; */